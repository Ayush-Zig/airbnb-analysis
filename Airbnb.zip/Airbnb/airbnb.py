import streamlit as st
import pandas as pd
import plotly.express as px

st.title("🏠 Airbnb Data Dashboard")

# Load dataset once
df = pd.read_csv('Clean_Airbnb_Data.csv', low_memory=False)

# Sidebar filters
location = st.sidebar.selectbox("Select Location", df['neighbourhood_group'].unique())
room_type = st.sidebar.multiselect("Room Type", df['room_type'].unique())

# Filter Data
filtered = df[(df['neighbourhood_group'] == location) & (df['room_type'].isin(room_type))]

# Show table
st.dataframe(filtered)

# Price distribution
fig = px.histogram(filtered, x='price', nbins=50, title="Price Distribution")
st.plotly_chart(fig)
